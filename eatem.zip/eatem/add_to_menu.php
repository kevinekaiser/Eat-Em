<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
  <title>Adding food to your menu</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome
                            /4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
      integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ'
      crossorigin='anonymous'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  <meta name="Author" content="Joseph Gaudio" />
  <meta name="generator" content="emacs" />
  <link rel="shortcut icon" href="./logo.png" />
  <style>
    a { text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
</head>

<body>

<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <!--<a href="#about" class="w3-bar-item w3-button">Get the App</a>-->
      <a href="signout.php" class="w3-bar-item w3-button">
          <?php 
          session_start();
	    
          if (isset($_SESSION["username"])){
              echo "Sign out: ".$_SESSION["username"];
          }else{
              echo "Sign in"; 
          }
          ?>
            </a>
            
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <a href="restaurant_orders.php" class="w3-bar-item w3-button">View Orders</a>
    </div>
  </div>
</div>
<br/></br><br/>
<h1>Uploading An Item</h1>

<form enctype="multipart/form-data" method="post" action="add_items.php" id="add_item_form">

  <table class="">
    <tr>
      <td> Enter item name:
      </td>
      <td> <input type="text" name="item_name" />
      <input type="hidden" name="username" value="<?php $_REQUEST['username'] ?>"/>
      </td>
    </tr>
    <tr>
      <td> Choose a photo of item:
      </td>
      <td> <input type="file" name="item_image" />
      </td>
    </tr>
    <tr>
      <td> Price in US dollars:
      </td>
      <td> <input type="number" step="0.01" name="item_price" />
      </td>
    </tr>
    <tr>
	<tr>
      <td> Write a description for this item:
      </td>
      <td> <textarea rows="4" cols="50" name="item_description" form="add_item_form"
      placeholder = "Enter text here..."></textarea> 
<!--<input type="text" name="item_description" />-->
      </td>
    </tr>
      <td>
      </td>
      <td><input type="submit" value="Upload this Item"/>
      </td>
    </tr>
  </table>
  
</form>
<hr>
<h3 class="w3-center">Your existing items</h3>
<?php
require_once('./Connect.php');
require_once('./DBfuncs.php');
require_once('./debughelp.php');
 
$dbh = ConnectDB();
 
$menu_list = FetchArray($dbh, 'item');
 
foreach($menu_list as $item){
	 
	
	echo "<div class='w3-content' style='max-width:1100px;'>
  <div class='w3-row w3-padding-64' >
    <div class='w3-col m6 w3-padding-large w3-hide-small'>
     <img src='http://issoufkindo.org/eatem/user_images/$item->image' 
     class='w3-round w3-image w3-opacity-min' alt='Table Setting' width='600' height='750'>
    </div>

    <div class='w3-col m6 w3-padding-large'>
      <h1 class='w3-center'>$item->name</h1><br>
      <h5 class='w3-center'>$: $item->price</h5>
      <p class='w3-large'>$item->description<span class='w3-tag w3-light-grey'>
      seasonal</span> ingredients.</p>
      <button onclick='add_to_cart($item->id)' class = 'w3-button w3-deep-orange'>
      <i class='material-icons'
      style='font-size:48px;color:white'>border_color</i></button>
      
    </div>
  </div>
  </div>
  <hr>
  ";

}

?>

<footer style="border-top: 1px solid blue; margin-top: 1ex;">
 
<span style="float: right;">
<a href="http://validator.w3.org/check/referer">HTML5</a> /
<a href="http://jigsaw.w3.org/css-validator/check/referer?profile=css3">
    CSS3 </a>
</span>
</footer>

</body>
</html>