<?php 
/*
issouf kindo

register.php

*/
require_once('./Connect.php');
require_once('./debughelp.php');
require_once('./DBfuncs.php');

$name=$_REQUEST['Name'];
$email= $_REQUEST['Email'];
$message= $_REQUEST['Message'];


$dbh = ConnectDB();
try {
    
    
    
	$query = "INSERT INTO contact (sender_name, sender_email, message)
	VALUES ( :name, :email, :message);";
	
	$stmt_2 = $dbh->prepare($query);
	$stmt_2->bindParam(':name', $name);
	$stmt_2->bindParam(':email', $email);
	$stmt_2->bindParam(':message', $message);
	$stmt_2->execute();
	$message = "Thank You For contacting us!We will get back to you soon.";

	    ob_start();
	   header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	    ob_end_flush();

}
    


catch(PDOException $e)
{
	die('PDO error inserting movie:' . $e->getMessage() );
}





?>