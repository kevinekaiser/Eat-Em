<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Author" content="Kevin Kaiser" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>	
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #F5F5DC;}
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}
button:hover {
  opacity: 0.8;
}
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
img.avatar {
  width: 40%;
  border-radius: 50%;
}
.container {
  padding: 16px;
}
span.psw {
  float: right;
  padding-top: 16px;
}
/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <!--<a href="#about" class="w3-bar-item w3-button">Get the App</a>-->
      <a href="signin.php" class="w3-bar-item w3-button">
      <?php 
          session_start();
	    
          if (isset($_SESSION["username"])){
              echo "Sign out: ".$_SESSION["username"];
          }else{
              echo "Sign in"; 
          }
          ?></a>
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <a href="#contact" class="w3-bar-item w3-button">Help</a>
    </div>
  </div>
</div>
<h2>Login </h2>
<p>Log into your account for Eat'Em</p>

<form action="http://issoufkindo.org/eatem/login.php">

  <div class="container" style="background-color:#FFA500">
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
        
    <button type="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>
<?php
  
if (isset($_REQUEST['response'])){
	echo '<p><strong>Error: Incorrect credentials</strong></p>';
  }
  ?>



  <div class="container" style="background-color:#FFA500">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
</form>

</body>