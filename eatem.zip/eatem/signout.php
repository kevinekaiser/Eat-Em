<?php
session_start();
/*
issouf kindo
*/
// remove all session variables
unset($_SESSION["username"]) ;

session_unset(); 

// destroy the session 
session_destroy(); 

if(isset ($_SESSION["username"])){
    $mes="Enable to sign out!";
  header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$mes);  
}else{
  header("Location: http://issoufkindo.org/eatem/signin.php");   
}


?>