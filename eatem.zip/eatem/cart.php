
<!DOCTYPE html>
<html>
<title>Eatem</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/
                             font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
      integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' 
      crossorigin='anonymous'>
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>


<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <!--<a href="#about" class="w3-bar-item w3-button">Get the App</a>-->
      <a href="menu.php" class="w3-bar-item w3-button">Menu</a>
      <a href="signin.php" class="w3-bar-item w3-button"><?php 
          session_start();
	    
          if (isset($_SESSION["username"]) && !(is_null($_SESSION["username"]))){
              echo "Sign out".$_SESSION["username"];
          }else{
              echo "Sign in"; 
          }
          ?> </a>
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <a href="#contact" class="w3-bar-item w3-button">Help</a>
    </div>
  </div>
</div>
<br/><br/><br/>
</header>
<body>
<!-- Page content -->
<div class="w3-content" style="max-width:1100px">

<form method='get' action='order.php' name='form'>

	<h4>Order details</h4>
	
		<table border='0' cellpadding='0' width='550' id='table2'>
		<tr>
			<td width='250' height='31'><b>Item Description</b></td>
			<td align='center' width='100' height='31'><b>Quantity</b></td>
			<td align='right' height='31' width='60'><b>Price </b></td>
			<td align='right' height='31' width='140'><b>Total</b></td>
		</tr>

<?php
require_once('./Connect.php');
require_once('./DBfuncs.php');
require_once('./debughelp.php');
 
$dbh = ConnectDB();


if (isset($_REQUEST['ids'])&& (!empty($_REQUEST['ids']))){
    
    
    $ids = $_REQUEST['ids'];
    $ids =  explode(",",$ids);

$total = 0;

foreach($ids as $id){
           $menu_list = FetchMatches($dbh, 'item', 'id', $id); 

foreach($menu_list as $item){
    
$total = $total+ $item->price;
echo"

		<tr>
			<td width='250'>$item->name</td>
			<td align='center' width='100'>
			<input type='number' name='$item->id' size='5' tabindex='5' value='1' 
			onchange='calculate_total($item->price,$item->id)' id = '$item->id' ></td>
			<td align='right' width='60'>$ $item->price</td>
			<td align='right' width='140'>
			$<input type='text' name='total1' size='12' tabindex='99' 
			value='$item->price' id = 'total$item->id' disabled='disabled'></td>
		</tr>

";

}
     
 }
 
 $temp =$_REQUEST['ids'];
 
 echo"<tr>
			<td width='250'>&nbsp;</td>
			<td align='center' width='100'>&nbsp;</td>
			<td align='right' width='60'>&nbsp;</td>
			<td align='right' width='140'>&nbsp;</td>
		</tr>
		<tr>
			<td width='250'>
			<p align='right'><b>TOTALS:</b></td>
			<td align='center' width='100'>&nbsp;</td>
			<td align='right' width='60'>&nbsp;</td>
			<td align='right' width='140'>
			<input type ='hidden'  name='GrandTotal'
			 size='15' tabindex='99' value='$total' id = 'GrandTotal' ></input>
			 <span>$<span/><input type='text'  name='GrandTotal'
			 size='15' tabindex='99' value='$total' 
			 id = 'GrandTotal_2' disabled='disabled' ></input>
			 </td> 
			 
         <input type ='hidden' value='$temp' name='ids'></input>";
 
 
 
}else{
    
    echo "Your Cart is Empty";
}



?>	

		</tr>
		<tr>
			<td width='250'>&nbsp;</td>
			<td align='center' width='100'>&nbsp;</td>
			<td align='right' width='60'>&nbsp;</td>
			<td align='right' width='140'>&nbsp;</td>

	</tr>
	</table>
	<p>&nbsp;</p>
		<p>Please fill in the following information to place your order:</p>
	<table border='0' cellpadding='0' width='550' id='table1'>
		<tr>
			<td width='340' align='right'>First Name: </font></td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='first_name' size='30' 
			    tabindex='1' required></td>
		</tr>
			<tr>
			<td width='340' align='right'>Last Name: </font></td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='last_name' size='30' 
			    tabindex='1' required></td>
		</tr>
		<tr>
			<td width='340' align='right'>Email:</font></td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='email' size='30' 
			    tabindex='1'></td>
		</tr>
		<tr>
			<td width='340' align='right'>Phone Number:</td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='number' size='30' 
			    tabindex='1' required></td>
		</tr>
		<tr>
			<td width='340' align='right'>Address/Street number: </td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='number' name='street_name' size='30' 
			    tabindex='1' required></td>
		</tr>
		<tr>
			<td width='340' align='right'>Address/Street name: </td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='street_number' size='30' 
			    tabindex='1' required></td>
		</tr>
		<tr>
			<td width='340' align='right'>Apt number:</td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='apt' size='30' tabindex='1' ></td>
		</tr>
		<tr>
			<td width='340' align='right'>City:</td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='city' size='30' tabindex='1' 
			    required></td>
		</tr>
		<tr>
			<td width='340' align='right'>State:</td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='state' size='30' tabindex='1' 
			    required></td>
		</tr>
		<tr>
			<td width='340' align='right' >Zip Code:</td>
			<td width='10'>&nbsp;</td>
			<td width='200'><input type='text' name='zip' size='30' tabindex='1' 
			    required></td>
		</tr>
	</table>
	


<p>Select order type:</p>
			<input type="radio" name="order_type" value="delivery"> Delivery<br>
			<input type="radio" name="order_type" value="pickup" checked="checked"> Pick Up<br>
			<p>Select payment type:</p>

Credit/Debit Card <input type="radio" onclick="javascript:yesnoCheck();" name="yesno" 
                         id="yesCheck"> Cash  
<input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="noCheck" 
       checked="checked"><br>
    <div id="ifYes" style="display:none">
        Name On Card: <input type='text' id='name_on_card' name='name_on_card'><br>
        Credit Card Number: <input type='text' id='ccnumber' name='ccnumber'><br>
		Exp Date: <input type='month' id='exp_date' name='exp_date'><br>
		CVV: <input type='text' id='cvv' name='cvv'><br>
    </div>
    
	<table border='0' cellpadding='0' width='550' id='table3'>
		<tr>
			<td width='563'>
			<p align='center'>
			<input type='submit' value='Checkout' name='subButton' tabindex='50'>
			&nbsp;&nbsp;&nbsp;&nbsp; 
			<input type='reset' value='Cancel' name='resetButton' tabindex='50'></td>
		</tr>
	</table>
</form>
</div>

<footer style="border-top: 1px solid blue; margin-top: 1ex;">
 
<span style="float: right;">
<a href="http://validator.w3.org/check/referer">HTML5</a> /
<a href="http://jigsaw.w3.org/css-validator/check/referer?profile=css3">
    CSS3 </a>
</span>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>

    var oldTotal=0;
    function  calculate_total ( price, id){
    var q =  document.getElementById(id).value;
    
    oldTotal = document.getElementById("total"+id).value;
    var t = q * price;
    document.getElementById("total"+id).value = t;
    
    var Gt = document.getElementById("GrandTotal").value;
    
    var temp = Gt - oldTotal;
    var temp2 = temp + t;
     document.getElementById("GrandTotal").value =temp2;
     document.getElementById("GrandTotal_2").value =temp2;
     
    } 
    
    
    function yesnoCheck() {
    if (document.getElementById('yesCheck').checked) {
        document.getElementById('ifYes').style.display = 'block';
    }
    else document.getElementById('ifYes').style.display = 'none';
}
    
</script>

</body>
</html>
