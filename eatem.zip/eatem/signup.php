<!DOCTYPE html>
<html>
    
<title>Eatem</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Author" content="Kevin Kaiser" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
	integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>


<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
hr {
  border: 1px solid #F5F5DC;
  margin-bottom: 25px;
}
/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
button:hover {
  opacity:1;
}
/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}
/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}
/* Add padding to container elements */
.container {
  padding: 16px;
}
/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}
/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body bgcolor="#FFA500">

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <!--<a href="#about" class="w3-bar-item w3-button">Get the App</a>-->
      <a href="menu.php" class="w3-bar-item w3-button">Menu</a>
      <a href="signin.php" class="w3-bar-item w3-button">
      
      <?php 
          session_start();
	    
          if (isset($_SESSION["username"])){
              echo "Sign out: ".$_SESSION["username"];
          }else{
              echo "Sign in"; 
          }
          ?> </a>
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <a href="#contact" class="w3-bar-item w3-button">Help</a>
    </div>
  </div>
</div>
<br/><br/><br/>
<form action="register.php" style="border:1px solid #ccc">
  <div class="container">
    <h1>Sign Up</h1>
    <p>Create your account for Eat'Em</p>
    <hr>
	<?php
	if (isset($_REQUEST['message'])){
	echo "<br/><strong>".$_REQUEST['message']."</strong></br>";
  }
	?>
	<label for="first_name"><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="first_name" required>
	
	<label for="last_name"><b>Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="last_name" required>

    <label for="username"><b>Enter your username</b></label>
    <input type="text" placeholder="Enter your username" name="username" required>


    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="email"><b>Number</b></label>
    <input type="text" placeholder="Enter Phone Number" name="number" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <!--<label for="psw-repeat"><b>Repeat Password</b></label>-->
    <!--<input type="password" placeholder="Repeat Password" name="psw-repeat" required>-->
	
	<input type="radio" name="user_type" value="restaurant"> Restaurant<br>
	<input type="radio" name="user_type" value="customer"> Customer<br>

    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
  </div>
</form>

</body>
</html>
