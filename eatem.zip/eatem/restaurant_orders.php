
<!DOCTYPE html>
<html>
<title>Eat'Em</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" 
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
      integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' 
      crossorigin='anonymous'>
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.button {
  background-color: #f44336; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}
.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}
.button1:hover {
  background-color: #4CAF50;
  color: white;
}
</style>
<body>
    
    <!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <!--<a href="#about" class="w3-bar-item w3-button">Get the App</a>-->
      <a href="signin.php" class="w3-bar-item w3-button">
          <?php 
          session_start();
	    
          if (isset($_SESSION["username"]) && (!empty($_SESSION["username"]))){
              echo "Sign out";
          }else{
              echo "Sign in"; 
          }
          ?>
          </a>
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <a href="#contact" class="w3-bar-item w3-button">Help</a>
    </div>
  </div>
</div>
<div>
<br/>
<br/>
<br/>
<div class="w3-container">
<h2 class="w3-xxlarge" >
 <p></p>   
<table>
  <tr>
    <th>Order #</th>
    <th>first name</th>
    <th>Status</th>
    <th>Total</th>
    <th>Action</th>
  </tr>
<?php
require_once('./Connect.php');
require_once('./DBfuncs.php');
require_once('./debughelp.php');

//session_start();

if (isset($_SESSION["user_type"]) && ($_SESSION["user_type"] =='restaurant')){

 
$dbh = ConnectDB();

$query="SELECT orders.total, orders.order_number, users.first_name,
orders.order_status,orders.order_type
FROM orders
INNER JOIN users
ON orders.user_id=users.id order by orders.order_date DESC ;";

    $stmt_2 = $dbh->prepare($query);
	$stmt_2->execute();

$orders =$stmt_2->fetchAll(PDO::FETCH_OBJ) ;

foreach($orders as $order){
 echo"
  <tr>
    <td>$order->order_number</td>
    <td>$order->first_name</td>
    <td>$order->order_type/$order->order_status</td>
    <td>$ $order->total</td>
    <td><button id ='$order->order_number' onclick ='complete_order($order->order_number)' 
    class='button button1'>complete</button>
    <button onclick ='cancel_order($order->order_number)' 
    class='button button1'>Cancel</button></td>
  </tr>";
    
}
}else{
    
    $message = "Please signin!";
    
     ob_start();
	 header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	 ob_end_flush();
}
  
  ?>
  
 </h2> 
 </div>
 <div>
     
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>


function complete_order( order_number )
{
    $.ajax({
         type: "POST",
         url: "complete_order.php",
         data: "order_number=" + order_number,
         success: function(){
                      $("p").html(" Order <b style='color:red'>Completed</b>!")
                  }
    });
 
 
}   
  function cancel_order( order_number )
{
    $.ajax({
         type: "POST",
         url: "cancel.php",
         data: "order_number=" + order_number,
         success: function(){
                      $("p").html(" Order <b style='color:red'>Canceled</b>!")
                  }
    });
}
  

</script>
     
 </div>
 
 
 
  </body>