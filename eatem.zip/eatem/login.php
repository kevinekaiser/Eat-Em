<?php 

require_once('./Connect.php');
require_once('./debughelp.php');
require_once('./DBfuncs.php');

$dbh = ConnectDB();
$u = $_REQUEST['username'];
$p = md5($_REQUEST['password']);
try {
    
    
	$query = "SELECT user_type, username from users". 
	"where username=:username AND password=:password";
	
	$list= FetchMatches($dbh,'users','username',$u);
	
// 	$stmt_2 = $dbh->prepare($query);
// 	$stmt_2->bindParam(':username',$u);
// 	$stmt_2->bindParam(':password',$p );
// 	$stmt_2->execute();
// 	$respons = $stmt_2->fetchAll(PDO::FETCH_OBJ);

	if ($list){
	    session_start();
	    $_SESSION["username"] = $u;
        $_SESSION["user_type"] = $list[0]->user_type;
	   if($list[0]->user_type =="restaurant"){
	   
	   //print_r(array_values($list));;
	   
	   // if ($respons["user_type"] =="restaurant"){
	    ob_start();
	    header('Location: http://issoufkindo.org/eatem/add_to_menu.php?username='.$u);
	    ob_end_flush();
	        
	    }else {
	        
	    ob_start();
	    header('Location: http://issoufkindo.org/eatem/menu.php');
	    ob_end_flush();
	    }
	}else{
	    ob_start();
	    header('Location: http://issoufkindo.org/eatem/signin.php?response=false');
	    ob_end_flush();
	    
	}

}
catch(PDOException $e)
{
	die('PDO error inserting movie:' . $e->getMessage() );
}





?>