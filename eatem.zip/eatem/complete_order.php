<?php 
require_once('./Connect.php');
require_once('./debughelp.php');
require_once('./DBfuncs.php');

$order_number = $_REQUEST['order_number'];

$dbh = ConnectDB();
try {
    
    // $list= FetchMatches($dbh,'orders','order_number',$order_number);
    
	$query = "UPDATE orders SET order_status ='complete'".
	        "where order_number=:order_number ";
	$stmt_2 = $dbh->prepare($query);
	$stmt_2->bindParam(':order_number',$order_number);
	$stmt_2->execute();
}
catch(PDOException $e)
{
	die('PDO error inserting movie:' . $e->getMessage() );
}
?>