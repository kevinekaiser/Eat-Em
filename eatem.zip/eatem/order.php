<?php 
/*
issouf kindo

register.php

*/
require_once('./Connect.php');
require_once('./debughelp.php');
require_once('./DBfuncs.php');

$first_name=$_REQUEST['first_name'];
$last_name=$_REQUEST['last_name'];
$email= $_REQUEST['email'];
$number= $_REQUEST['number'];
$order_type= $_REQUEST['order_type'];
$street_number = $_REQUEST['street_number'];
$street_name = $_REQUEST['street_name'];
$city = $_REQUEST['city'];
$state = $_REQUEST['state'];
$zip = $_REQUEST['zip'];
$name_on_card = $_REQUEST['name_on_card'];
$ccnumber = $_REQUEST['ccnumber'];
$exp_date = $_REQUEST['exp_date'];
$cvv = $_REQUEST['cvv'];
$ids = $_REQUEST['ids'];
$GrandTotal = $_REQUEST['GrandTotal'];



$dbh = ConnectDB();
try {
    
//   print_r($ids);
    $order_number = rand(10,100);
    
    $check= FetchMatches($dbh,'oders','order_number',$order_number);
    while ($check){
    $order_number = rand(10,100);
    $check= FetchMatches($dbh,'oders','order_number',$order_number);
    }
    
    
    if (isset ($_REQUEST['ids']) && $_REQUEST['ids'] != 0){
      
     $user= FetchMatches($dbh,'users','number',$number); 
        
    if ($user){
       //user already exists 
       
       $query_7 = "INSERT INTO users (order_number)
    	VALUES (:order_number) where number=:number;";
    	
    	
    	$stmt_7 = $dbh->prepare($query_7);
    	$stmt_7->bindParam(':order_number',$order_number);
    	$stmt_7->bindParam(':number', $user->number);
    	$stmt_7->execute();
    }else{
        
     
    	$query = "INSERT INTO users (first_name,user_type, 
    	last_name,order_number, email, number)
    	VALUES ( :first_name, :last_name,:user_type , 
    	:order_number , :email, :number);";
    	$c ='customer';
    	
    	
    	
    	$stmt_2 = $dbh->prepare($query);
    	$stmt_2->bindParam(':first_name', $first_name);
    	$stmt_2->bindParam(':last_name', $last_name);
     	$stmt_2->bindParam(':user_type',$c);
    	$stmt_2->bindParam(':order_number',$order_number);
    	$stmt_2->bindParam(':email',$email);
    	$stmt_2->bindParam(':number', $number);
    	$stmt_2->execute();
    	$user= FetchMatches($dbh,'users','order_number',$order_number);
    }
	$ids =  explode(",",$ids);
	
	foreach ($ids as $id){
	$query_3 = "INSERT INTO cart (order_number, items_id)
	VALUES ( :order_number, :items_id);";

	
	$stmt_3 = $dbh->prepare($query_3);
	$stmt_3->bindParam(':items_id',$id);
	$stmt_3->bindParam(':order_number',$order_number);
	$stmt_3->execute();
	}

	$query_4 = "INSERT INTO location (street_name,street_number,
	city, state,zip, apt,user_id,label)
	VALUES ( :street_name, :street_number,
	:city, :state , :zip, :apt,:user_id,:label);";
	$sh = 'shipping address';
	$stmt_4 = $dbh->prepare($query_4);
	$stmt_4->bindParam(':street_name',$street_name);
	$stmt_4->bindParam(':street_number',$street_number);
	$stmt_4->bindParam(':city',$city);
	$stmt_4->bindParam(':state',$state);
	$stmt_4->bindParam(':zip',$zip);
	$stmt_4->bindParam(':apt',$apt);
	$stmt_4->bindParam(':user_id',$user[0]->id);
	$stmt_4->bindParam(':label',$sh);
	$stmt_4->execute();
	
	
	
    $query_1 = "INSERT INTO orders (user_id,order_number,cart_number,security_code
	,name_on_cart, total,cart_exp_date,order_type)
	VALUES ( :user_id, :order_number , :cart_number , :security_code, 
	:name_on_cart,:total, :cart_exp_date, :order_type);";
	
	$stmt_1 = $dbh->prepare($query_1);
	$stmt_1->bindParam(':user_id', $user[0]->id);
	$stmt_1->bindParam(':order_number',$order_number);
	$stmt_1->bindParam(':order_type',$order_type);
	$stmt_1->bindParam(':cart_number', $ccnumber);
	$stmt_1->bindParam(':security_code',$cvv);
	$stmt_1->bindParam(':name_on_cart', $name_on_card); 
	$stmt_1->bindParam(':total', $GrandTotal);
	$stmt_1->bindParam(':cart_exp_date', $exp_date);
	$stmt_1->execute();
	
	
	
	$message = "Thank You For ordering!Your order number is: ".$order_number;

	    ob_start();
	    header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	    ob_end_flush();
	    
    }else{
       	$message = "No item selected";
	    ob_start();
	    header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	    ob_end_flush(); 
    }

}
    
// }

catch(PDOException $e)
{
	die('PDO error inserting movie:' . $e->getMessage() );
}





?>