
<!DOCTYPE html>
<html>
<title>Eat'Em</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' 
crossorigin='anonymous'>
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
<body>
    
    <!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      
      <a href="signout.php" class="w3-bar-item w3-button">
          <?php 
          session_start();
	    
          if (isset($_SESSION["username"]) && (!empty($_SESSION["username"]))){
              echo "Sign out";
              echo "<a href='track_my_order.php' class='w3-bar-item w3-button'>Track Your Order</a>";
          }else{
              echo "Sign in"; 
          }
          ?>
          </a>
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <a href="#contact" class="w3-bar-item w3-button">Help</a>
    </div>
  </div>
</div>
<div>
<br/>
<br/>
<br/>
<div class="w3-container">
<h2 class="w3-xxlarge" >
<?php

if (isset($_REQUEST['message'])){
	echo $_REQUEST['message'];
  }
  
  ?>
  
 </h2> 
 </div>
  </body>