<?php 
/*
issouf kindo

register.php

*/
require_once('./Connect.php');
require_once('./debughelp.php');
require_once('./DBfuncs.php');

$first_name=$_REQUEST['first_name'];
$last_name=$_REQUEST['last_name'];
$username = $_REQUEST['username'];
$user_type= $_REQUEST['user_type'];
$password = md5($_REQUEST['password']);
$email= $_REQUEST['email'];
$number= $_REQUEST['number'];


$dbh = ConnectDB();
try {
    
    $list= FetchMatches($dbh,'users','username',$username);
    
    if ($list){
      $message = "This username is already taken, please try again!"; 
        ob_start();
	    header("Location: http://issoufkindo.org/eatem/signup.php?message=".$message);
	    ob_end_flush();
    }else{
    
    
	$query = "INSERT INTO users (first_name, last_name, username, user_type, password, email, number)
	VALUES ( :first_name, :last_name, :username, :user_type , :password , :email, :number);";
	
	$stmt_2 = $dbh->prepare($query);
	$stmt_2->bindParam(':first_name', $first_name);
	$stmt_2->bindParam(':last_name', $last_name);
	$stmt_2->bindParam(':username', $username);
	$stmt_2->bindParam(':user_type',$user_type);
	$stmt_2->bindParam(':password', $password);
	$stmt_2->bindParam(':email',$email);
	$stmt_2->bindParam(':number', $number);
	$stmt_2->execute();
	$message = "Thank You For registering! Please login";

	    ob_start();
	    header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	    ob_end_flush();

}
    
}

catch(PDOException $e)
{
	die('PDO error inserting movie:' . $e->getMessage() );
}





?>