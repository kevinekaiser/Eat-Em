<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
  <title>Menu</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" 
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
      integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' 
      crossorigin='anonymous'>

  
  <meta name="Author" content="Joseph Gaudio" />
  <meta name="generator" content="emacs" />
  <link rel="shortcut icon" href="./logo.png" />
  <style>
    a { text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
  <script>
/*
issouf kindo
*/
var ids = [];
var count=0;
var price_ = 0;

function add_to_cart(id,price){
  ids[count] = id;
  var bt = document.getElementById("add_to_cart_bt"+id).value ;
  document.getElementById("add_to_cart_bt"+id).disabled = true;
     count = count + 1;
     price_ = price_ + price;
    document.getElementById("cart_count").innerHTML = count;
    document.getElementById("total").innerHTML = price_;
    
}

function send_data_to_cart(){
    
  window.open("http://issoufkindo.org/eatem/cart.php?ids="+ids);   
    
}


// $(document).ready(function(){
//   $("#add_to_cart_bt"+id_).click(function (){
//      count = count + 1; 
//     $("#cart_count").html(count);
//   });
// });
</script>
</head>

<body>

<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="http://issoufkindo.org/eatem/" class="w3-bar-item w3-button">Eat'Em</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <!--<a href="#about" class="w3-bar-item w3-button">Get the App</a>-->
      <a href="signout.php" class="w3-bar-item w3-button">
         
         <?php 
          session_start();
	    
          if (isset($_SESSION["username"])){
              echo "Sign out: ".$_SESSION["username"];
              echo "<a href='track_my_order.php' class='w3-bar-item w3-button'>
              Track Your Order</a>";
          }else{
              echo "Sign in"; 
          }
          ?> 
      </a>
       <a href="signup.php" class="w3-bar-item w3-button">Sign up</a>
      <!--<a href="#contact" class="w3-bar-item w3-button">Help</a>-->
      <button onclick="send_data_to_cart()" class="w3-bar-item w3-button" id="cart">
          <i class="fa fa-shopping-cart"></i> Cart 
          <span class="badge" id="cart_count" style="color:red">0</span>
          </button>
          <span class="w3-bar-item lighter-text">Total:</span>
        <span class="w3-bar-item  main-color-text" id = 'total'>$0</span>
    </div>
  </div>
</div>
<br/><br/><br/>
<?php
require_once('./Connect.php');
require_once('./DBfuncs.php');
require_once('./debughelp.php');
 
$dbh = ConnectDB();
 
$menu_list = FetchArray($dbh, 'item');
 
foreach($menu_list as $item){
	 
	
	echo "<div class='w3-content' style='max-width:1100px;'>
  <div class='w3-row w3-padding-64' >
    <div class='w3-col m6 w3-padding-large w3-hide-small'>
     <img src='http://issoufkindo.org/eatem/user_images/$item->image' 
	 class='w3-round w3-image w3-opacity-min' alt='Table Setting' width='600' height='750'>
    </div>

    <div class='w3-col m6 w3-padding-large'>
      <h1 class='w3-center'>$item->name</h1><br>
      <h5 class='w3-center'>$: $item->price</h5>
      <p class='w3-large'>$item->description<span class='w3-tag w3-light-grey'></p>
      <button onclick='add_to_cart($item->id,$item->price)' 
	  class = 'w3-button w3-deep-orange' id='add_to_cart_bt$item->id'>Order</button>
      
    </div>
  </div>
  </div>
  <hr>
  ";

}

?>

<footer style="border-top: 1px solid blue; margin-top: 1ex;">
 
<span style="float: right;">
<a href="http://validator.w3.org/check/referer">HTML5</a> /
<a href="http://jigsaw.w3.org/css-validator/check/referer?profile=css3">
    CSS3 </a>
</span>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>



</body>
</html>