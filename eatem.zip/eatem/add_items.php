<?php 
/*
issouf kindo

add_items.php

*/
require_once('./Connect.php');
require_once('./debughelp.php');
require_once('./DBfuncs.php');

$username = $_REQUEST["username"];
session_start();
if (isset($_SESSION["user_type"])){
$user_type= $_SESSION["user_type"];

$item_name = $_REQUEST['item_name'];
$item_description = $_REQUEST['item_description'];
$item_image = $_FILES['item_image']['name'];
$item_price = $_REQUEST['item_price'];


$dbh = ConnectDB();
try {
    
    if ($user_type == 'restaurant'){
	
$user= FetchMatches($dbh,'users','username',$username);


	
	$query_2 = "INSERT INTO item (name,description,image,price)".
	"VALUES ( :item_name, :item_description,:item_image,:item_price);";
	$stmt_2 = $dbh->prepare($query_2);
	$stmt_2->bindParam(':item_name', $item_name);
	$stmt_2->bindParam(':item_description', $item_description);
 	$stmt_2->bindParam(':item_image', $item_image);
	$stmt_2->bindParam(':item_price', $item_price);
	$stmt_2->execute();
	
	$stmt_2 = null;
	

            	$uploaddir = '/home/issoufki/public_html/eatem/user_images/';
                $uploadfile = $uploaddir . basename($_FILES['item_image']['name']);
            
            if (move_uploaded_file($_FILES['item_image']['tmp_name'], $uploadfile)) {
            } else {
              echo "Upload failed";
            }
	
     $items=  FetchMatches($dbh,'item','name',$item_name);
	print_r($items);
	
	$query_4 = "INSERT INTO menu (items_id, user_id) VALUES ( :items_id, :user_id);";
	$stmt_4 = $dbh->prepare($query_4);
	$stmt_4->bindParam(':user_id', $user[0]->id);
	$stmt_4->bindParam(':items_id', $items[0]->id);
	$stmt_4->execute();
	$message = "Item Added!";
    
	    ob_start();
	    header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	    ob_end_flush();

}
    
}

catch(PDOException $e)
{
	die('PDO error inserting movie:' . $e->getMessage() );
}

}else{
    $message = "Please signin!";
    
     ob_start();
	 header("Location: http://issoufkindo.org/eatem/thank_you.php?message=".$message);
	 ob_end_flush();

}



?>




